import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { classifyActivity } from '../../shared/classification/classifier.js';
import { app } from '../src/app.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../src/services/userStore.js';
import {
  getUserDir,
  getUserDeviceRecord,
  saveUserDeviceRecord,
  getUserTelemetry,
  saveUserTelemetry,
  getUserSessions,
  saveUserSessions,
  getUserSummary,
  saveUserSummary,
  getUserEventIndex,
  saveUserEventIndex,
} from '../src/services/dataStore.js';
import { createSessionForUser, toDeviceStatus } from '../src/services/authHelpers.js';
import http from 'http';

const testUserId = 'user_correction_verification_test';
const testDeviceToken = 'ct_dev_correction_verification_token';

function setupCleanTestUser() {
  const users = getUsers();
  let user = users.find((u) => u.id === testUserId);
  if (!user) {
    user = {
      id: testUserId,
      username: 'verification_tester',
      email: 'verification@chronotrace.local',
      name: 'Verification Engineer',
      deviceToken: testDeviceToken,
      hasConfiguredDevice: true,
      createdAt: new Date().toISOString(),
    };
    users.push(user);
    saveUsers(users);
  }

  saveUserDeviceRecord(testUserId, {
    paused: false,
    deviceName: 'Test-Workstation-11',
    os: 'Windows 11 Pro 64-bit',
    agentVersion: '1.3.0',
    samplingInterval: '500ms',
    lastHeartbeatAt: new Date().toISOString(),
    connectedSince: new Date().toISOString(),
    lastSuccessfulConnectionAt: new Date().toISOString(),
    lastEventTime: '10:00:00 AM',
    lastLocalDate: '2026-10-30',
  });

  saveUserTelemetry(testUserId, []);
  saveUserSessions(testUserId, []);
  saveUserSummary(testUserId, {
    date: '2026-10-30',
    total_telemetry_s: 0,
    total_deep_work_s: 0,
    total_distraction_s: 0,
    context_switches: 0,
    fragmentation_score: 0,
    peak_focus_window: '',
    distraction_triggers: [],
    daily_narrative: '',
  });
  saveUserEventIndex(testUserId, new Set());

  const { token } = createSessionForUser(user);
  return { user, token };
}

let server: http.Server;
let port: number;

function startServer(): Promise<void> {
  return new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      port = (server.address() as any).port;
      resolve();
    });
  });
}

function stopServer(): Promise<void> {
  return new Promise((resolve) => {
    server.close(() => resolve());
  });
}

async function apiCall(method: string, path: string, headers: Record<string, string>, body?: any) {
  const url = `http://127.0.0.1:${port}${path}`;
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: res.status, headers: res.headers, body: json || text };
}

describe('ChronoTrace Corrections & Validation Suite (Cases 1-8)', async () => {
  let userToken: string;
  let sessionToken: string;
  let agentHeaders: Record<string, string>;
  let authHeaders: Record<string, string>;

  it('Setup test environment', async () => {
    await startServer();
    const { token } = setupCleanTestUser();
    sessionToken = token;
    userToken = testDeviceToken;
    agentHeaders = { 'X-Device-Token': testDeviceToken };
    authHeaders = { Authorization: `Bearer ${sessionToken}` };
  });

  // CASE 1: Open Google AI Studio and verify classification
  it('CASE 1: Google AI Studio - distinguishes generic workspace from active coding API session', async () => {
    // 1a. Generic AI Studio overview without prompt/code context -> Unclassified, not blindly Deep Work
    const genericRes = classifyActivity('Google Chrome', 'Google AI Studio - Google Chrome', [], {
      domain: 'aistudio.google.com',
      url: 'https://aistudio.google.com/',
    });
    assert.equal(genericRes.category, 'Unclassified');
    assert.equal(genericRes.intent, 'UNKNOWN');
    assert.ok(genericRes.confidence <= 0.50);

    // 1b. Active prompt prototyping and Gemini API system instructions -> Coding / DEEP_WORK
    const codingRes = classifyActivity('Google Chrome', 'Gemini 2.5 Flash System Instructions and Function Calling API - Google AI Studio', [], {
      domain: 'aistudio.google.com',
      url: 'https://aistudio.google.com/prompts/new_chat',
    });
    assert.equal(codingRes.category, 'Coding');
    assert.equal(codingRes.intent, 'DEEP_WORK');
    assert.ok(codingRes.confidence >= 0.90);

    // Ingest into agent
    const res = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case1_aistudio_coding',
      appName: 'Google Chrome',
      windowTitle: 'Gemini 2.5 Flash System Instructions and Function Calling API - Google AI Studio',
      domain: 'aistudio.google.com',
      deltaSeconds: 60,
      localTime: '10:10:00 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
    assert.equal(res.status, 200);

    const sessions = getUserSessions(testUserId);
    assert.equal(sessions[sessions.length - 1].dominant_category, 'Coding');
  });

  // CASE 2: Open GitHub repository and verify title and sub-events remain correctly associated
  it('CASE 2: GitHub Repository - title and sub-events remain correctly associated without cross-contamination', async () => {
    // Ingest GitHub repository session
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case2_gh_event_1',
      appName: 'Google Chrome',
      windowTitle: 'sandhiya-git-hub/timetrace10: Passive activity reconstruction agent · GitHub',
      domain: 'github.com',
      deltaSeconds: 90,
      localTime: '10:15:00 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });

    // Ingest second page within same GitHub repo (commit view)
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case2_gh_event_2',
      appName: 'Google Chrome',
      windowTitle: 'Commit 4f2a1b - sandhiya-git-hub/timetrace10 · GitHub',
      domain: 'github.com',
      deltaSeconds: 60,
      localTime: '10:16:30 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });

    const sessions = getUserSessions(testUserId);
    const ghSession = sessions.find((s) => s.domain === 'github.com');
    assert.ok(ghSession);
    assert.equal(ghSession.dominant_category, 'Coding');
    assert.equal(ghSession.duration_s, 150);
    // Ensure both sub-events belong strictly to GitHub
    assert.ok(ghSession.main_events.length >= 1);
    ghSession.main_events.forEach((sub) => {
      assert.ok(sub.title.includes('GitHub') || sub.title.includes('timetrace10'));
      assert.equal(sub.title.includes('YouTube'), false);
    });
  });

  // CASE 3: Open YouTube briefly (2 seconds), verify not counted as 87-second distraction
  it('CASE 3: Brief YouTube transition (2s) is not merged into prior 85s session nor counted as 87s distraction', async () => {
    // Ingest a 2-second YouTube transition
    const ytRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case3_yt_brief_switch',
      appName: 'Google Chrome',
      windowTitle: 'YouTube - Google Chrome',
      domain: 'youtube.com',
      deltaSeconds: 2,
      click_count: 0,
      scroll_count: 0,
      key_count: 0,
      active_dwell_ms: 500,
      idle_dwell_ms: 1500,
      localTime: '10:18:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(ytRes.status, 200);

    const sessions = getUserSessions(testUserId);
    const ytSession = sessions[sessions.length - 1];
    assert.ok(ytSession);
    assert.equal(ytSession.duration_s, 2);
    // Verify it is NOT 87 seconds!
    assert.notEqual(ytSession.duration_s, 87);

    // Verify GitHub session was NOT contaminated with YouTube
    const ghSession = sessions.find((s) => s.domain === 'github.com');
    assert.ok(ghSession);
    assert.equal(ghSession.main_events.some((e) => e.title.includes('YouTube')), false);

    // Summary check: distraction must not be 87 seconds
    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', authHeaders);
    assert.equal(summaryRes.status, 200);
    assert.notEqual(summaryRes.body.total_distraction_s, 87);

    // Prompt Step 3 explicitly specifies: "Open YouTube briefly, then switch away."
    // Simulate user switching away back to coding/work
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case3_switch_away_to_work',
      appName: 'Google Chrome',
      windowTitle: 'sandhiya-git-hub/timetrace10: Passive activity reconstruction agent · GitHub',
      domain: 'github.com',
      deltaSeconds: 15,
      localTime: '10:18:05 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
  });

  // CASE 4: Watch YouTube video for longer period, verify dwell and active durations are exact
  it('CASE 4: Sustained YouTube session - dwell and active durations accurately recorded', async () => {
    const res = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case4_yt_sustained',
      appName: 'Google Chrome',
      windowTitle: 'Lofi Chill Hip Hop Beats to Study & Relax - YouTube',
      domain: 'youtube.com',
      deltaSeconds: 240,
      click_count: 4,
      scroll_count: 2,
      key_count: 0,
      active_dwell_ms: 220000,
      idle_dwell_ms: 20000,
      localTime: '10:20:00 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });
    assert.equal(res.status, 200);

    const sessions = getUserSessions(testUserId);
    const sustainedYt = sessions.find((s) => s.main_events?.some((e) => e.title.includes('Lofi Chill')));
    assert.ok(sustainedYt);
    assert.equal(sustainedYt.duration_s, 240);
    assert.equal(sustainedYt.active_duration_s, 220);
    assert.equal(sustainedYt.idle_duration_s, 20);
    assert.equal(sustainedYt.dominant_category, 'Entertainment');
  });

  // CASE 5: Open Google Calendar, verify duration matches across Activity, Timeline, and Dashboard
  it('CASE 5: Google Calendar - duration matches identically across Activity, Timeline, and Dashboard', async () => {
    const calDwell = 180;
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case5_cal_event',
      appName: 'Google Chrome',
      windowTitle: 'Google Calendar - Week of Oct 30, 2026',
      domain: 'calendar.google.com',
      deltaSeconds: calDwell,
      localTime: '10:25:00 AM',
      localDate: '2026-10-30',
      sourceType: 'browser-extension',
    });

    // 1. Raw Telemetry Activity Table verification
    const telemRes = await apiCall('GET', '/api/telemetry/raw?limit=50', authHeaders);
    assert.equal(telemRes.status, 200);
    const calRaw = telemRes.body.events.find((e: any) => e.id === 'case5_cal_event');
    assert.ok(calRaw);
    assert.equal(calRaw.duration_s, calDwell);
    assert.equal(calRaw.category, 'Productivity & Planning');

    // 2. Timeline Reconstructed Sessions verification
    const sessRes = await apiCall('GET', '/api/sessions', authHeaders);
    assert.equal(sessRes.status, 200);
    const sessionsList = Array.isArray(sessRes.body) ? sessRes.body : sessRes.body.sessions;
    const calSession = sessionsList.find((s: any) => s.domain === 'calendar.google.com');
    assert.ok(calSession);
    assert.equal(calSession.duration_s, calDwell);
    assert.equal(calSession.dominant_category, 'Productivity & Planning');

    // 3. Dashboard Summary verification
    const summaryRes = await apiCall('GET', '/api/summary?startDate=2026-10-30&endDate=2026-10-30', authHeaders);
    assert.equal(summaryRes.status, 200);
    assert.equal(summaryRes.body.category_breakdown['Productivity & Planning'], calDwell);
  });

  // CASE 6: Open VS Code and project file, verify reconstruction and classification
  it('CASE 6: VS Code - project buffer reconstructed as Coding / DEEP_WORK session', async () => {
    await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case6_vscode_project',
      appName: 'VS Code',
      windowTitle: 'server.ts - ChronoTrace - Visual Studio Code',
      deltaSeconds: 300,
      click_count: 35,
      key_count: 220,
      active_dwell_ms: 290000,
      idle_dwell_ms: 10000,
      localTime: '10:30:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });

    const sessions = getUserSessions(testUserId);
    const vsSession = sessions.find((s) => s.anchor_app === 'VS Code');
    assert.ok(vsSession);
    assert.equal(vsSession.dominant_category, 'Coding');
    assert.equal(vsSession.intent, 'DEEP_WORK');
    assert.equal(vsSession.duration_s, 300);
  });

  // CASE 7: Disconnect agent, verify historical records remain visible and connection state changes
  it('CASE 7: Agent Disconnection - preserves historical telemetry while transitioning status to DISCONNECTED', async () => {
    const devRec = getUserDeviceRecord(testUserId);
    // Simulate stopping agent: last heartbeat 75s ago
    devRec.lastHeartbeatAt = new Date(Date.now() - 75000).toISOString();
    saveUserDeviceRecord(testUserId, devRec);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, false);
    assert.equal(statusRes.body.status, 'DISCONNECTED');
    assert.equal(statusRes.body.isHistorical, true);

    // Verify all historical telemetry events and sessions remain completely preserved!
    const telem = getUserTelemetry(testUserId);
    assert.ok(telem.length >= 6);
    const sessions = getUserSessions(testUserId);
    assert.ok(sessions.length >= 4);
  });

  // CASE 8: Reconnect agent, verify new events received without duplicates
  it('CASE 8: Agent Reconnection - restores CONNECTED status and receives events with strict deduplication', async () => {
    // 8a. Fresh heartbeat arrives
    const hbRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      heartbeat: true,
      sourceType: 'heartbeat',
    });
    assert.equal(hbRes.status, 200);

    const statusRes = await apiCall('GET', '/api/device/status', authHeaders);
    assert.equal(statusRes.status, 200);
    assert.equal(statusRes.body.connected, true);
    assert.equal(statusRes.body.status, 'CONNECTED');

    // 8b. Ingest new event
    const newEventRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case8_reconnect_new_event',
      appName: 'VS Code',
      windowTitle: 'routes.ts - ChronoTrace - Visual Studio Code',
      deltaSeconds: 100,
      localTime: '11:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(newEventRes.status, 200);
    assert.equal(newEventRes.body.duplicate, false);

    // 8c. Submitting duplicate identical event is rejected
    const dupEventRes = await apiCall('POST', '/api/ingest-event', agentHeaders, {
      id: 'case8_reconnect_new_event',
      appName: 'VS Code',
      windowTitle: 'routes.ts - ChronoTrace - Visual Studio Code',
      deltaSeconds: 100,
      localTime: '11:00:00 AM',
      localDate: '2026-10-30',
      sourceType: 'os-hook',
    });
    assert.equal(dupEventRes.status, 200);
    assert.equal(dupEventRes.body.duplicate, true);
  });

  it('Teardown test server', async () => {
    await stopServer();
  });
});
