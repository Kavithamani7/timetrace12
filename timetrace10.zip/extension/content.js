/**
 * ChronoTrace Browser Sensor - Privacy-Safe Content Script
 * 
 * Measures aggregated interaction signals (scroll counts, clicks, key counts)
 * and active/idle time without EVER reading text, keystrokes, passwords, or inputs.
 */

(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__chronotrace_sensor_installed) return;
  window.__chronotrace_sensor_installed = true;

  let clicks = 0;
  let scrolls = 0;
  let keyEvents = 0;
  let mouseMoves = 0;
  let lastInteractionTime = Date.now();
  let lastReportTime = Date.now();
  let isPageVisible = document.visibilityState === 'visible';

  const IDLE_TIMEOUT_MS = 30000; // 30s without interaction marks tab as idle

  // Listen to visibility changes
  document.addEventListener('visibilitychange', () => {
    isPageVisible = document.visibilityState === 'visible';
    if (isPageVisible) {
      lastInteractionTime = Date.now();
    }
    reportEngagement();
  });

  // Track clicks safely (counter only, no target or coordinates)
  window.addEventListener('click', () => {
    clicks++;
    lastInteractionTime = Date.now();
  }, { passive: true, capture: true });

  // Track scrolls safely (throttled counter only)
  let scrollTimeout = null;
  window.addEventListener('scroll', () => {
    if (!scrollTimeout) {
      scrolls++;
      lastInteractionTime = Date.now();
      scrollTimeout = setTimeout(() => {
        scrollTimeout = null;
      }, 500);
    }
  }, { passive: true, capture: true });

  // Track mouse movements safely (throttled counter only, NEVER coordinates or cursor positions)
  let mouseMoveTimeout = null;
  window.addEventListener('mousemove', () => {
    if (!mouseMoveTimeout) {
      mouseMoves++;
      lastInteractionTime = Date.now();
      mouseMoveTimeout = setTimeout(() => {
        mouseMoveTimeout = null;
      }, 500);
    }
  }, { passive: true, capture: true });

  // Track key events count (NO key values, NO characters, NO text, NO passwords)
  window.addEventListener('keydown', () => {
    keyEvents++;
    lastInteractionTime = Date.now();
  }, { passive: true, capture: true });

  function reportEngagement() {
    const now = Date.now();
    const elapsedSinceLastReport = Math.max(1, now - lastReportTime);
    lastReportTime = now;

    const idlePeriod = now - lastInteractionTime;
    const isCurrentlyIdle = idlePeriod > IDLE_TIMEOUT_MS;

    let activeDwellMs = 0;
    let idleDwellMs = 0;

    if (isPageVisible) {
      if (isCurrentlyIdle) {
        idleDwellMs = elapsedSinceLastReport;
      } else {
        activeDwellMs = elapsedSinceLastReport;
      }
    }

    const payload = {
      type: 'CHRONOTRACE_ENGAGEMENT_PING',
      url: window.location.href,
      domain: window.location.hostname.replace(/^www\./, '').toLowerCase(),
      title: document.title || window.location.hostname,
      clicks,
      scrolls,
      keyEvents,
      mouseMoves,
      activeDwellMs,
      idleDwellMs,
      isCurrentlyIdle,
      isVisible: isPageVisible,
    };

    // Reset counters for next reporting interval
    clicks = 0;
    scrolls = 0;
    keyEvents = 0;
    mouseMoves = 0;

    try {
      if (chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(payload).catch(() => {});
      }
    } catch {
      // Non-fatal if extension context reloaded
    }
  }

  // Periodic report every 3 seconds
  setInterval(reportEngagement, 3000);

  // Final flush before unload
  window.addEventListener('beforeunload', () => {
    reportEngagement();
  });
})();
