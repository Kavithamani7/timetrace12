export function getStoredSessionToken(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return (
      localStorage.getItem('chronotrace_session_token') ||
      sessionStorage.getItem('chronotrace_session_token')
    );
  } catch {
    return null;
  }
}

export function setStoredSessionToken(token: string | null) {
  if (typeof window === 'undefined') return;
  try {
    if (token) {
      localStorage.setItem('chronotrace_session_token', token);
    } else {
      localStorage.removeItem('chronotrace_session_token');
      sessionStorage.removeItem('chronotrace_session_token');
    }
  } catch {}
}

export function getAuthHeaders(): Record<string, string> {
  const token = getStoredSessionToken();
  if (!token) return {};
  return {
    Authorization: `Bearer ${token}`,
    'X-Session-Token': token,
  };
}

export async function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const authHeaders = getAuthHeaders();
  const headers = new Headers(init?.headers);

  Object.entries(authHeaders).forEach(([k, v]) => {
    if (!headers.has(k)) {
      headers.set(k, v);
    }
  });

  return fetch(input, {
    ...init,
    cache: 'no-store',
    credentials: 'include',
    headers,
  });
}

export async function apiFetchJson<T = any>(input: RequestInfo | URL, init?: RequestInit): Promise<T | null> {
  try {
    const res = await apiFetch(input, init);
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}
