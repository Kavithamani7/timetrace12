import assert from 'assert';
import { classifyActivity } from '../shared/classification/classifier.js';

const SERVER_BASE = 'http://localhost:3000';

async function request(url: string, options: any = {}) {
  const res = await fetch(url, options);
  const text = await res.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: res.status, text, json };
}

async function runScenarioNavigationVerification() {
  console.log('================================================================');
  console.log(' CHRONOTRACE SCENARIO NAVIGATION & INTELLIGENCE VERIFICATION');
  console.log('================================================================\n');

  // Register clean user
  const rand = Math.floor(10000 + Math.random() * 90000);
  const regRes = await request(`${SERVER_BASE}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: `navtest${rand}`,
      email: `navtest${rand}@example.com`,
      name: 'Navigation Tester',
      password: 'Password123!',
      confirmPassword: 'Password123!',
    }),
  });

  const user = regRes.json.user;
  const token = regRes.json.sessionToken || regRes.json.token;
  const deviceToken = user.deviceToken;
  const authHeaders = {
    'Authorization': `Bearer ${token}`,
    'Cookie': `chronotrace_session=${token}`,
  };

  const scenarios = [
    // 1. Google AI Studio
    {
      name: 'Google AI Studio - Gemini 2.5 Flash System Prompting',
      app: 'Google Chrome',
      title: 'Gemini 2.5 Flash System Instructions and Function Calling API - Google AI Studio',
      url: 'https://aistudio.google.com/prompts/new_chat',
      domain: 'aistudio.google.com',
      dwell: 150,
      activeDwell: 140,
      idleDwell: 10,
      clicks: 12,
      scrolls: 25,
      keys: 40,
      expectedCategory: 'Coding',
      expectedIntent: 'DEEP_WORK',
      expectedEngagement: 'engaged',
    },
    {
      name: 'Google AI Studio - Model Benchmarking & Evaluation',
      app: 'Google Chrome',
      title: 'Multimodal Benchmark Evaluation Matrix - Google AI Studio',
      url: 'https://aistudio.google.com/evals',
      domain: 'aistudio.google.com',
      dwell: 90,
      activeDwell: 85,
      idleDwell: 5,
      clicks: 8,
      scrolls: 18,
      keys: 5,
      expectedCategory: 'Research',
      expectedIntent: 'LEARNING',
      expectedEngagement: 'engaged',
    },
    // 2. GitHub Repositories
    {
      name: 'GitHub - Pull Request & Code Review',
      app: 'Google Chrome',
      title: 'Fix concurrent render edge case · Pull Request #28000 · facebook/react · GitHub',
      url: 'https://github.com/facebook/react/pull/28000',
      domain: 'github.com',
      dwell: 180,
      activeDwell: 170,
      idleDwell: 10,
      clicks: 16,
      scrolls: 35,
      keys: 20,
      expectedCategory: 'Coding',
      expectedIntent: 'DEEP_WORK',
      expectedEngagement: 'engaged',
    },
    // 3. Claude Project Conversations
    {
      name: 'Claude - Refactoring TypeScript Backend',
      app: 'Google Chrome',
      title: 'Refactoring TypeScript Backend Express Routes - Claude',
      url: 'https://claude.ai/chat/project_123',
      domain: 'claude.ai',
      dwell: 200,
      activeDwell: 190,
      idleDwell: 10,
      clicks: 10,
      scrolls: 40,
      keys: 60,
      expectedCategory: 'Coding',
      expectedIntent: 'DEEP_WORK',
      expectedEngagement: 'engaged',
    },
    {
      name: 'Claude - Scientific Literature Analysis',
      app: 'Google Chrome',
      title: 'Analysis of Quantum Computing Papers and Literature - Claude',
      url: 'https://claude.ai/chat/paper_analysis',
      domain: 'claude.ai',
      dwell: 160,
      activeDwell: 150,
      idleDwell: 10,
      clicks: 6,
      scrolls: 30,
      keys: 15,
      expectedCategory: 'Research',
      expectedIntent: 'LEARNING',
      expectedEngagement: 'engaged',
    },
    // 4. Google Calendar
    {
      name: 'Google Calendar - Sprint Planning Schedule',
      app: 'Google Chrome',
      title: 'Google Calendar - Week of Oct 30, 2026',
      url: 'https://calendar.google.com/calendar/u/0/r',
      domain: 'calendar.google.com',
      dwell: 60,
      activeDwell: 55,
      idleDwell: 5,
      clicks: 9,
      scrolls: 8,
      keys: 2,
      expectedCategory: 'Productivity & Planning',
      expectedIntent: 'ADMIN',
      expectedEngagement: 'engaged',
    },
    // 5. Instagram Educational vs Entertainment
    {
      name: 'Instagram - Neurobiology & Science Study Account',
      app: 'Google Chrome',
      title: 'Andrew Huberman Science of Sleep and Focus · Instagram',
      url: 'https://www.instagram.com/hubermanlab/',
      domain: 'instagram.com',
      dwell: 90,
      activeDwell: 85,
      idleDwell: 5,
      clicks: 5,
      scrolls: 22,
      keys: 0,
      expectedCategory: 'Study',
      expectedIntent: 'LEARNING',
      expectedEngagement: 'engaged',
    },
    {
      name: 'Instagram - Reels & Viral Memes Entertainment',
      app: 'Google Chrome',
      title: 'Funny Pranks and Comedy Reels · Instagram',
      url: 'https://www.instagram.com/reels/comedy/',
      domain: 'instagram.com',
      dwell: 120,
      activeDwell: 110,
      idleDwell: 10,
      clicks: 14,
      scrolls: 50,
      keys: 0,
      expectedCategory: 'Entertainment',
      expectedIntent: 'DISTRACTION',
      expectedEngagement: 'engaged',
    },
    // 6. YouTube Educational vs Entertainment
    {
      name: 'YouTube - Dijkstra Algorithm Graph Theory Tutorial',
      app: 'Google Chrome',
      title: 'Dijkstra Algorithm and Graph Theory Tutorial - YouTube',
      url: 'https://www.youtube.com/watch?v=algorithm123',
      domain: 'youtube.com',
      dwell: 240,
      activeDwell: 220,
      idleDwell: 20,
      clicks: 4,
      scrolls: 15,
      keys: 0,
      expectedCategory: 'Study',
      expectedIntent: 'LEARNING',
      expectedEngagement: 'engaged',
    },
    {
      name: 'YouTube - Official Movie Trailer Entertainment',
      app: 'Google Chrome',
      title: 'Inception Official Movie Trailer - YouTube',
      url: 'https://www.youtube.com/watch?v=trailer456',
      domain: 'youtube.com',
      dwell: 150,
      activeDwell: 140,
      idleDwell: 10,
      clicks: 2,
      scrolls: 4,
      keys: 0,
      expectedCategory: 'Entertainment',
      expectedIntent: 'DISTRACTION',
      expectedEngagement: 'engaged',
    },
    // 7. PowerShell & Windows Applications
    {
      name: 'PowerShell - ChronoTrace Background Collector (Excluded)',
      app: 'PowerShell',
      title: 'PowerShell - python chronotrace_agent.py',
      url: '',
      domain: '',
      dwell: 45,
      activeDwell: 40,
      idleDwell: 5,
      clicks: 0,
      scrolls: 0,
      keys: 0,
      expectedCategory: 'Utilities',
      expectedIntent: 'ADMIN',
      expectedEngagement: 'passive',
      isCollector: true,
    },
    {
      name: 'PowerShell - Developer Git and Build Commands',
      app: 'PowerShell',
      title: 'PowerShell - git commit -m "feat: activity intelligence" && npm run build',
      url: '',
      domain: '',
      dwell: 80,
      activeDwell: 75,
      idleDwell: 5,
      clicks: 0,
      scrolls: 0,
      keys: 25,
      expectedCategory: 'Coding',
      expectedIntent: 'DEEP_WORK',
      expectedEngagement: 'engaged',
    },
    {
      name: 'Windows App - Calculator (Utility)',
      app: 'Calculator',
      title: 'Calculator',
      url: '',
      domain: '',
      dwell: 30,
      activeDwell: 28,
      idleDwell: 2,
      clicks: 12,
      scrolls: 0,
      keys: 15,
      expectedCategory: 'Utilities',
      expectedIntent: 'ADMIN',
      expectedEngagement: 'engaged',
    },
  ];

  console.log(`Starting execution of ${scenarios.length} realistic scenarios...\n`);

  for (let idx = 0; idx < scenarios.length; idx++) {
    const sc = scenarios[idx];
    console.log(`--- [TEST ${idx + 1}/${scenarios.length}] ${sc.name} ---`);

    // 1. Ingest event
    const eventId = `evt_sc_${idx}_${Date.now()}`;
    const payload = {
      id: eventId,
      appName: sc.app,
      windowTitle: sc.title,
      url: sc.url,
      domain: sc.domain,
      deltaSeconds: sc.dwell,
      durationSeconds: sc.dwell,
      dwell_ms: sc.dwell * 1000,
      active_dwell_ms: sc.activeDwell * 1000,
      idle_dwell_ms: sc.idleDwell * 1000,
      click_count: sc.clicks,
      scroll_count: sc.scrolls,
      key_count: sc.keys,
      sourceType: sc.url ? 'browser-extension' : 'os-hook',
      localTime: '10:00:00 AM',
      localDate: '2026-10-30',
    };

    const res = await request(`${SERVER_BASE}/api/ingest-event`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Token': deviceToken,
        'Authorization': `Bearer ${deviceToken}`,
      },
      body: JSON.stringify(payload),
    });

    assert.equal(res.status, 200, `Ingestion returned status ${res.status}`);
    const classification = res.json.event;

    // 2. Inspect Raw Event & Classification
    console.log(`  Raw Event: app="${classification.app_name}", title="${classification.window_title}"`);
    console.log(`  Classification: category="${classification.category}", intent="${classification.intent}", confidence=${classification.confidence}`);
    console.log(`  Reason: "${classification.classification_reason}"`);
    console.log(`  Engagement State: "${classification.engagement_state}"`);

    assert.equal(
      classification.category,
      sc.expectedCategory,
      `Category mismatch: expected "${sc.expectedCategory}", got "${classification.category}"`
    );
    assert.ok(
      classification.intent === sc.expectedIntent ||
      (sc.expectedIntent === 'DISTRACTION' && classification.intent === 'DISTRACTION_BREAK'),
      `Intent mismatch: expected "${sc.expectedIntent}", got "${classification.intent}"`
    );
    if (sc.isCollector) {
      assert.equal(classification.is_collector_process, true, 'Expected collector process flag to be true');
    }
  }

  // 3. Inspect Reconstructed Sessions
  console.log('\n--> Inspecting Reconstructed Sessions from /api/sessions...');
  const sessRes = await request(`${SERVER_BASE}/api/sessions`, { headers: authHeaders });
  assert.equal(sessRes.status, 200);
  const sessions = sessRes.json;
  console.log(`  Total Reconstructed Sessions: ${sessions.length}`);

  sessions.forEach((s: any, i: number) => {
    console.log(`  [Session ${i + 1}] app="${s.anchor_app}", cat="${s.dominant_category}", intent="${s.intent}", duration=${s.duration_s}s, active=${s.active_duration_s}s, engagement=${s.engagement_score}%`);
  });

  // 4. Inspect Dashboard Summary Result
  console.log('\n--> Inspecting Dashboard Analytics Result from /api/summary...');
  const sumRes = await request(`${SERVER_BASE}/api/summary`, { headers: authHeaders });
  assert.equal(sumRes.status, 200);
  const summary = sumRes.json;

  console.log('  Summary Output:', {
    total_telemetry_s: summary.total_telemetry_s,
    pure_deep_work_s: summary.pure_deep_work_s,
    total_learning_s: summary.total_learning_s,
    total_entertainment_s: summary.total_entertainment_s,
    total_productivity_planning_s: summary.total_productivity_planning_s,
    total_utilities_s: summary.total_utilities_s,
    measured_focus_s: summary.measured_focus_s,
    work_state: summary.work_state,
    overall_engagement_score: summary.overall_engagement_score,
  });

  // Verify collector was excluded from deep work metrics
  assert.ok(summary.pure_deep_work_s > 0, 'Expected positive pure deep work');
  assert.ok(summary.total_learning_s > 0, 'Expected positive learning');
  assert.ok(summary.total_productivity_planning_s === 60, 'Expected 60s for Google Calendar');
  assert.ok(summary.overall_engagement_score > 50, `Expected honest engagement score > 50%, got ${summary.overall_engagement_score}%`);

  console.log('\n================================================================');
  console.log(' ALL 13 TEST SCENARIOS PASSED WITH EXACT VERIFIED METRICS!');
  console.log('================================================================');
}

runScenarioNavigationVerification().catch((err) => {
  console.error('[TEST FAILURE]', err);
  process.exit(1);
});
